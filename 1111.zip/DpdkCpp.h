#pragma once
#include <unordered_map>
namespace pcpp
{

typedef struct _SWriteNodeInfo
{
FILE *fp;
uint32_t writecount;
uint32_t writetimer;
}WriteNodeInfo;

class DpdkUserBinThread
{
protected:
	bool m_bStop;
public:
	DpdkUserBinThread():m_bStop(false){}
	virtual ~DpdkUserBinThread() {}
		
	virtual std::unordered_map<uint64_t,WriteNodeInfo>& GetWriteHashFilePtr()
	{
		std::unordered_map<uint64_t,WriteNodeInfo> hashmaplist;
		return hashmaplist;
	}
	virtual void WriteRun100ms(uint64_t hasharr[],uint32_t len){};
};


class DpdkCpp
{
private:
	DpdkCpp(){}
	void CheckAllPortsLinkStatus(unsigned int port_mask);

	int InitEal();
	int InitPortQueue();
	int InitAllPort();
	void LaunchAllLcore();
	void CloseAllPort();


	public:
	virtual ~DpdkCpp(){}
	static inline DpdkCpp& GetInstance()
	{
		static DpdkCpp instance;
		return instance;
	}

	int InitDpdk(DpdkUserBinThread* rxthread,DpdkUserBinThread* statthread,DpdkUserBinThread* writethread);

};


};

