#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/queue.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <setjmp.h>
#include <stdarg.h>
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <signal.h>
#include <stdbool.h>
#include <unistd.h>

#include <rte_common.h>
#include <rte_log.h>
#include <rte_memory.h>
#include <rte_memcpy.h>
#include <rte_memzone.h>
#include <rte_eal.h>
#include <rte_per_lcore.h>
#include <rte_launch.h>
#include <rte_atomic.h>
#include <rte_cycles.h>
#include <rte_prefetch.h>
#include <rte_lcore.h>
#include <rte_per_lcore.h>
#include <rte_branch_prediction.h>
#include <rte_interrupts.h>
#include <rte_pci.h>
#include <rte_random.h>
#include <rte_debug.h>
#include <rte_ether.h>
#include <rte_arp.h>
#include <rte_ip.h>
#include <rte_tcp.h>
#include <rte_udp.h>
#include <rte_icmp.h>
#include <rte_ethdev.h>
#include <rte_ring.h>
#include <rte_mempool.h>
#include <rte_mbuf.h>

#include "pcapng.h"

#include "PacketWriteThread.h"


namespace pcpp
{


uint32_t PacketWriteThread::m_maxWriteCount= 10000;//1����
uint32_t PacketWriteThread::m_maxWriteTimeMax= 10*10;//10����


void PacketWriteThread::WritePcapngHeader(FILE *fp)
{
	struct block_header bh;
	struct section_header_block shb;
	struct block_trailer bt;
	struct interface_description_block idb;
	struct option_header oh;
	uint32_t msb = 6;

	bh.block_type = BT_SHB;
	bh.total_length = 28;
	fwrite(&bh, 1, sizeof(struct block_header), fp);
	shb.byte_order_magic = BYTE_ORDER_MAGIC;
	shb.major_version = PCAP_NG_VERSION_MAJOR;
	shb.minor_version = PCAP_NG_VERSION_MINOR;
	shb.section_length = 0xFFFFFFFFFFFFFFFF;
	fwrite(&shb, 1, sizeof(struct section_header_block), fp);
	bt.total_length = 28;
	fwrite(&bt, 1, sizeof(struct block_trailer), fp);

	bh.block_type = BT_IDB;
	bh.total_length = 32;
	fwrite(&bh, 1, sizeof(struct block_header), fp);
	idb.linktype = 1;
	idb.reserved = 0;
	idb.snaplen = 0xFFFF;
	fwrite(&idb, 1, sizeof(struct interface_description_block), fp);
	oh.option_code = 9;
	oh.option_length = 1;
	fwrite(&oh, 1, sizeof(struct option_header), fp);
	fwrite(&msb, 1, sizeof(uint32_t), fp);
	oh.option_code = OPT_ENDOFOPT;
	oh.option_length = 0;
	fwrite(&oh, 1, sizeof(struct option_header), fp);
	bt.total_length = 32;
	fwrite(&bt, 1, sizeof(struct block_trailer), fp);
}

PacketWriteThread::PacketWriteThread()
{
	
}

PacketWriteThread::~PacketWriteThread()
{
	for(auto& writenode:m_writeHashNodes)
		if(writenode.second.fp)
			fclose(writenode.second.fp);

	m_writeHashNodes.clear();
}

void PacketWriteThread::CheckWriteStatus()
{	

	std::unordered_map<uint64_t,WriteNodeInfo>::iterator writenode;

	for(writenode= m_writeHashNodes.begin();writenode!= m_writeHashNodes.end();)
	{
		++(writenode->second.writetimer);
		bool berase= false;
		if(unlikely(writenode->second.writecount>=m_maxWriteCount ))
		{
			berase= true;
		}

		if(unlikely(writenode->second.writetimer>=m_maxWriteTimeMax ))
		{
			berase= true;
		}
		if(unlikely(berase))
		{
			fclose(writenode->second.fp);
			writenode= m_writeHashNodes.erase(writenode);
		}
		else
			++writenode;
	}

}

void PacketWriteThread::WriteRun100ms(uint64_t excpthasharr[],uint32_t len)
{
	std::unordered_map<uint64_t,WriteNodeInfo>::iterator writenode;
	for(uint32_t i= 0;i< len;++i)
	{
		writenode= m_writeHashNodes.find(excpthasharr[i]);
		if(writenode== m_writeHashNodes.end())
		{
			char m_fileName[128];
			WriteNodeInfo writenode;
			memset(m_fileName,0,128);
			sprintf(m_fileName,"%u.pcapng",excpthasharr[i]);
			writenode.fp = fopen(m_fileName, "wb");
			if (NULL!= writenode.fp)
			{
				WritePcapngHeader(writenode.fp);
				writenode.writecount= 0;
				writenode.writetimer= 0;
			}

		}


	}

	CheckWriteStatus();
}


};
