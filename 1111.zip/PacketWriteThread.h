#pragma once
#include "DpdkCpp.h"
#include <stdint.h>
#include <inttypes.h>
#include <unordered_map>

namespace pcpp
{



class PacketWriteThread:public DpdkUserBinThread
{
private:
	static uint32_t m_maxWriteCount;//1万条
	static uint32_t m_maxWriteTimeMax;//10分钟

private:
	std::unordered_map<uint64_t,WriteNodeInfo> m_writeHashNodes;

	void WritePcapngHeader(FILE *fp);
	void CheckWriteStatus();
public:
	PacketWriteThread();
	virtual ~PacketWriteThread();

	virtual std::unordered_map<uint64_t,WriteNodeInfo>& GetWriteHashFilePtr()
	{
		return m_writeHashNodes;
	}

	virtual void WriteRun100ms(uint64_t hasharr[],uint32_t len);	
};

};
