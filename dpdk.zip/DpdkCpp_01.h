#pragma once

namespace pcpp
{

	class DpdkUserBinThread
	{
	protected:
		bool m_bStop;
	public:
		DpdkUserBinThread():m_bStop(false){}
		virtual ~DpdkUserBinThread() {}
		virtual bool Run(uint64_t hasharr[],uint8_t *packet[],uint32_t len){return m_bStop;};
		virtual void Stop(){};
	};


class DpdkCpp
{
private:
	DpdkCpp(){}
	void CheckAllPortsLinkStatus(unsigned int port_mask);

	int InitEal();
	int InitPortQueue();
	int InitAllPort();
	void LaunchAllLcore();
	void CloseAllPort();


	public:
	virtual ~DpdkCpp(){}
	static inline DpdkCpp& GetInstance()
	{
		static DpdkCpp instance;
		return instance;
	}

	int InitDpdk(DpdkUserBinThread* rxthread,DpdkUserBinThread* statthread,DpdkUserBinThread* writethread);

};


};

