#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <sys/types.h>
#include <sys/queue.h>
#include <netinet/in.h>
#include <setjmp.h>
#include <stdarg.h>
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <signal.h>
#include <stdbool.h>

#include <rte_common.h>
#include <rte_log.h>
#include <rte_malloc.h>
#include <rte_memory.h>
#include <rte_memcpy.h>
#include <rte_eal.h>
#include <rte_launch.h>
#include <rte_atomic.h>
#include <rte_cycles.h>
#include <rte_prefetch.h>
#include <rte_lcore.h>
#include <rte_per_lcore.h>
#include <rte_branch_prediction.h>
#include <rte_interrupts.h>
#include <rte_random.h>
#include <rte_debug.h>
#include <rte_ether.h>
#include <rte_ethdev.h>
#include <rte_mempool.h>
#include <rte_mbuf.h>


#include "pcapng.h"
#include "DpdkCpp.h"


namespace pcpp
{
static volatile bool force_quit;

/* MAC updating enabled by default */
static int mac_updating = 1;

#define RTE_LOGTYPE_L2FWD RTE_LOGTYPE_USER1
#define CAPTURE_RING_SIZE (2048 * 4)

#define MAX_PKT_BURST 256
#define BURST_TX_DRAIN_US 10000 /* TX drain every ~100us */
#define MEMPOOL_CACHE_SIZE 1024

/*
 * Configurable number of RX/TX ring descriptors
 */
#define RTE_TEST_RX_DESC_DEFAULT 1024
#define RTE_TEST_TX_DESC_DEFAULT 1024
static uint16_t nb_rxd = RTE_TEST_RX_DESC_DEFAULT;
static uint16_t nb_txd = RTE_TEST_TX_DESC_DEFAULT;


/* mask of enabled ports */
static uint32_t l2fwd_enabled_port_mask = 0;
static uint32_t l2fwd_enabled_core_mask = 0x07;

struct capture_port_conf {
	uint8_t dst_port;
	struct ether_addr eth_addr;
	struct rte_ring *worker_ring;
	struct rte_ring *tx_ring;
} __rte_cache_aligned;
struct capture_port_conf capture_port_conf[RTE_MAX_ETHPORTS];


static unsigned int l2fwd_rx_queue_per_lcore = 2;

#define MAX_RX_QUEUE_PER_LCORE 16
#define MAX_TX_QUEUE_PER_PORT 16
struct lcore_queue_conf {
	unsigned n_rx_port;
	unsigned rx_port_list[MAX_RX_QUEUE_PER_LCORE];
} __rte_cache_aligned;
struct lcore_queue_conf lcore_queue_conf[RTE_MAX_LCORE];

enum lcore_type_conf
{
	unused = 0,
	rx,
	tx,
	stat,
	write
}lcore_type_conf[RTE_MAX_LCORE]; //0 for unused, 1 for RX, 2 for TX, 3 for worker

static struct rte_eth_dev_tx_buffer *tx_buffer[RTE_MAX_ETHPORTS];

static struct rte_eth_conf port_conf;
struct rte_mempool * l2fwd_pktmbuf_pool = NULL;

/* Per-port statistics struct */
struct l2fwd_port_statistics {
	uint64_t tx;
	uint64_t rx;
	uint64_t dropped;
} __rte_cache_aligned;
struct l2fwd_port_statistics port_statistics[RTE_MAX_ETHPORTS];

#define MAX_TIMER_PERIOD 86400 /* 1 day max */
/* A tsc-based timer responsible for triggering statistics printout */
static uint64_t timer_period = 1; /* default period is 10 seconds */

/* Print out statistics on packets dropped */
static void print_stats(void)
{
	uint64_t total_packets_dropped, total_packets_tx, total_packets_rx;
	unsigned portid;

	total_packets_dropped = 0;
	total_packets_tx = 0;
	total_packets_rx = 0;

	const char clr[] = { 27, '[', '2', 'J', '\0' };
	const char topLeft[] = { 27, '[', '1', ';', '1', 'H','\0' };

		/* Clear screen and move to top left */
	printf("%s%s", clr, topLeft);

	printf("\nPort statistics ====================================");

	for (portid = 0; portid < RTE_MAX_ETHPORTS; portid++) {
		/* skip disabled ports */
		if ((l2fwd_enabled_port_mask & (1 << portid)) == 0)
			continue;
		printf("\nStatistics for port %u ------------------------------"
			   "\nPackets sent: %24"PRIu64
			   "\nPackets received: %20"PRIu64
			   "\nPackets dropped: %21"PRIu64,
			   portid,
			   port_statistics[portid].tx,
			   port_statistics[portid].rx,
			   port_statistics[portid].dropped);

		total_packets_dropped += port_statistics[portid].dropped;
		total_packets_tx += port_statistics[portid].tx;
		total_packets_rx += port_statistics[portid].rx;
	}
	printf("\nAggregate statistics ==============================="
		   "\nTotal packets sent: %18"PRIu64
		   "\nTotal packets received: %14"PRIu64
		   "\nTotal packets dropped: %15"PRIu64,
		   total_packets_tx,
		   total_packets_rx,
		   total_packets_dropped);
	printf("\n====================================================\n");
}


static void l2fwd_mac_updating(struct rte_mbuf *m, unsigned dest_portid)
{
	struct ether_hdr *eth;
	void *tmp;

	eth = rte_pktmbuf_mtod(m, struct ether_hdr *);

	/* 02:00:00:00:00:xx */
	tmp = &eth->d_addr.addr_bytes[0];
	*((uint64_t *)tmp) = 0x000000000002 + ((uint64_t)dest_portid << 40);

	/* src addr */
	
	ether_addr_copy(&capture_port_conf[dest_portid].eth_addr, &eth->s_addr);
}
static void l2fwd_simple_forward(struct rte_mbuf *m, unsigned portid)
{
	unsigned dst_port;
	int sent;
	struct rte_eth_dev_tx_buffer *buffer;

	dst_port = capture_port_conf[portid].dst_port;

	if (mac_updating)
		l2fwd_mac_updating(m, dst_port);

	buffer = tx_buffer[dst_port];
	sent = rte_eth_tx_buffer(dst_port, 0, buffer, m);
	if (sent)
		port_statistics[dst_port].tx += sent;

}


static void
pcapng_header_write(FILE *fp)
{
	struct block_header bh;
	struct section_header_block shb;
	struct block_trailer bt;
	struct interface_description_block idb;
	struct option_header oh;
	uint32_t msb = 6;

	bh.block_type = BT_SHB;
	bh.total_length = 28;
	fwrite(&bh, 1, sizeof(struct block_header), fp);
	shb.byte_order_magic = BYTE_ORDER_MAGIC;
	shb.major_version = PCAP_NG_VERSION_MAJOR;
	shb.minor_version = PCAP_NG_VERSION_MINOR;
	shb.section_length = 0xFFFFFFFFFFFFFFFF;
	fwrite(&shb, 1, sizeof(struct section_header_block), fp);
	bt.total_length = 28;
	fwrite(&bt, 1, sizeof(struct block_trailer), fp);

	bh.block_type = BT_IDB;
	bh.total_length = 32;
	fwrite(&bh, 1, sizeof(struct block_header), fp);
	idb.linktype = 1;
	idb.reserved = 0;
	idb.snaplen = 0xFFFF;
	fwrite(&idb, 1, sizeof(struct interface_description_block), fp);
	oh.option_code = 9;
	oh.option_length = 1;
	fwrite(&oh, 1, sizeof(struct option_header), fp);
	fwrite(&msb, 1, sizeof(uint32_t), fp);
	oh.option_code = OPT_ENDOFOPT;
	oh.option_length = 0;
	fwrite(&oh, 1, sizeof(struct option_header), fp);
	bt.total_length = 32;
	fwrite(&bt, 1, sizeof(struct block_trailer), fp);
}

static void
pcapng_epb_write(FILE *fp, uint8_t *packet, uint64_t pkt_len, uint64_t arrival_time)
{
	struct block_header bh;
	struct enhanced_packet_block epb;
	struct block_trailer bt;
	int ret = 0;
	uint32_t offset = 0;
	uint32_t padding = 0;
	uint32_t fakepadding = 0;

	offset = pkt_len;
	padding = offset % 4 ? (4 - offset % 4) : 0;
	bh.block_type = BT_EPB;
	bh.total_length = 32 + offset + padding;
	bt.total_length = 32 + offset + padding;
	epb.interface_id = 0;
	epb.timestamp_high = (uint32_t)(arrival_time >> 32);
	epb.timestamp_low = (uint32_t)arrival_time;
	epb.caplen = offset;
	epb.len = offset;
	fwrite(&bh, 1, sizeof(struct block_header), fp);
	fwrite(&epb, 1, sizeof(struct enhanced_packet_block), fp);
	ret = fwrite(packet, 1, pkt_len, fp);
	ret += fwrite(&fakepadding, 1, padding, fp);
	fwrite(&bt, 1, sizeof(struct block_trailer), fp);
}

DpdkUserBinThread* gwritethread= NULL;

//* rx processing loop 
static void capture_rx_loop(void)
{
	struct rte_mbuf *pkts_burst[MAX_PKT_BURST];
	struct rte_mbuf *m;
	int sent;
	unsigned lcore_id;
	uint64_t prev_tsc, diff_tsc, cur_tsc, timer_tsc;
	unsigned i, j, portid, nb_rx;
	struct lcore_queue_conf *qconf;
	const uint64_t drain_tsc = (rte_get_tsc_hz() + US_PER_S - 1) / US_PER_S *
			BURST_TX_DRAIN_US;
	struct rte_eth_dev_tx_buffer *buffer;

	prev_tsc = 0;
	timer_tsc = 0;

	lcore_id = rte_lcore_id();
	qconf = &lcore_queue_conf[lcore_id];

	if(NULL==gwritethread)
	{
		RTE_LOG(INFO, L2FWD, "ERROR:write thread ptr is null\n");
		return ;
	}


	if (qconf->n_rx_port == 0) {
		RTE_LOG(INFO, L2FWD, "lcore %u has nothing to do\n", lcore_id);
		return ;
	}

	RTE_LOG(INFO, L2FWD, "entering main loop on lcore %u\n", lcore_id);

	while (!force_quit) {

		cur_tsc = rte_rdtsc();

		/*
		 * TX burst queue drain
		 */
		diff_tsc = cur_tsc - prev_tsc;
		if (unlikely(diff_tsc > drain_tsc)) {

			for (i = 0; i < qconf->n_rx_port; i++) {

				portid = capture_port_conf[qconf->rx_port_list[i]].dst_port;
				buffer = tx_buffer[portid];

				sent = rte_eth_tx_buffer_flush(portid, 0, buffer);
				if (sent)
					port_statistics[portid].tx += sent;

			}

			/* if timer is enabled */
			if (timer_period > 0) {

				/* advance the timer */
				timer_tsc += diff_tsc;

				/* if timer has reached its timeout */
				if (unlikely(timer_tsc >= timer_period)) {

					/* do this only on master core */
					if (lcore_id == rte_get_master_lcore()) {
						//print_stats();
						/* reset the timer */
						timer_tsc = 0;
					}
				}
			}

			prev_tsc = cur_tsc;
		}

		/*
		 * Read packet from RX queues
		 */
		for (i = 0; i < qconf->n_rx_port; i++) {

			portid = qconf->rx_port_list[i];
			nb_rx = rte_eth_rx_burst(portid, 0,
						 pkts_burst, MAX_PKT_BURST);

			port_statistics[portid].rx += nb_rx;

			for (j = 0; j < nb_rx; j++) {
				m = pkts_burst[j];
				rte_prefetch0(rte_pktmbuf_mtod(m, void *));
				l2fwd_simple_forward(m, portid);
			}
		}
	}

	return ;

}

/* tx processing loop */
static void
capture_tx_loop(void)
{
	struct rte_mbuf *mbufs[MAX_PKT_BURST];
	unsigned lcore_id;
	unsigned i, portid, nb_tx;
	struct lcore_queue_conf *qconf;
	uint32_t dqnum;

	lcore_id = rte_lcore_id();
	qconf = &lcore_queue_conf[lcore_id];

	RTE_LOG(INFO, L2FWD, "entering tx loop on lcore %u\n", lcore_id);

	while (!force_quit) {
		/*
		 * Send packet to TX queues
		 */
		for (i = 0; i < qconf->n_rx_port; i++) {
			portid = qconf->rx_port_list[i];
			dqnum = rte_ring_dequeue_burst(capture_port_conf[portid].tx_ring, (void **)&mbufs, MAX_PKT_BURST,NULL);
			if (unlikely(dqnum == 0))
                continue;

			nb_tx = rte_eth_tx_burst((uint8_t) portid, 0, mbufs, dqnum);

			if (unlikely(nb_tx < dqnum))
			{
				unsigned k;
				for (k = nb_tx; k < dqnum; k++)
				{
					struct rte_mbuf *m = mbufs[k];
					rte_pktmbuf_free(m);
				}
			}
		}
	}
}


/* worker processing loop */
static void
capture_worker_loop(void)
{
	struct rte_mbuf *mbufs[MAX_PKT_BURST];
	struct rte_mbuf *m;
	unsigned lcore_id;
	unsigned i, j, portid;
	struct lcore_queue_conf *qconf;
	uint32_t dqnum, eqnum;
	uint8_t dst_port;
	uint8_t *packet;

	FILE *fp = NULL;
	int pcapng_saved_count=0,pcapng_not_saved_count=0;
	int save_pcapng_enabled= 1;
	lcore_id = rte_lcore_id();
	qconf = &lcore_queue_conf[lcore_id];

	RTE_LOG(INFO, L2FWD, "entering worker loop on lcore %u\n", lcore_id);

	if(save_pcapng_enabled)
	{
		fp = fopen("port.pcapng", "wb");
		if (fp == NULL)
		{
			printf("Cannot open pcapng file.\n");
			save_pcapng_enabled = 0;
		}
		else
			pcapng_header_write(fp);
	}
	else
	{
		printf("Pcapng save not enabled.\n");
	}

	while (!force_quit) 
	{
		/*
		 * Read packet from worker ring
		 */
		for (i = 0; i < qconf->n_rx_port; i++) {

			portid = qconf->rx_port_list[i];
			dqnum = rte_ring_dequeue_burst(capture_port_conf[portid].worker_ring, (void **)&mbufs, MAX_PKT_BURST,NULL);
			dst_port = capture_port_conf[portid].dst_port;

			if (unlikely(dqnum == 0))
                continue;

            for (j = 0; j < dqnum; j++)
            {
            	m = mbufs[j];

            	if ((fp != NULL && rte_ring_count(capture_port_conf[portid].worker_ring) < MAX_PKT_BURST) && save_pcapng_enabled)
            	{
            		packet = rte_pktmbuf_mtod(m, uint8_t *);
            		pcapng_epb_write(fp, packet, rte_pktmbuf_data_len(m), m->udata64);
            		pcapng_saved_count++;
            		printf("pcapng_saved_count=%d \n",pcapng_saved_count);
            	}
            	else
            	{
            		pcapng_not_saved_count++;
            	}

            	if(unlikely(dst_port > RTE_MAX_ETHPORTS))
            	{
            		rte_pktmbuf_free(m);
            		continue;
            	}
            }

            if(unlikely(dst_port > RTE_MAX_ETHPORTS))
            	continue;
            
            eqnum = rte_ring_enqueue_burst(capture_port_conf[dst_port].tx_ring, (void **)mbufs, dqnum,NULL);

			if (unlikely(eqnum < dqnum))
			{
				unsigned k;
				for (k = eqnum; k < dqnum; k++)
				{
					struct rte_mbuf *m_temp = mbufs[k];
					rte_pktmbuf_free(m_temp);
				}
			}
		}
	}

	if (fp != NULL)
		fclose(fp);
}

//* main processing loop 
int l2fwd_launch_one_lcore(__attribute__((unused)) void *dummy)
{
	unsigned lcore_id = rte_lcore_id();

	switch(lcore_type_conf[lcore_id])
	{
		case rx:
			capture_rx_loop();
			printf("***Lcore: %u Type: RX\n", lcore_id);
			break;
		case stat:
			printf("***Lcore: %u Type: STAT\n", lcore_id);
			break;
		case write:
			printf("***Lcore: %u Type: WRITE\n", lcore_id);
			break;
		default:
			printf("***Lcore: %u Type: unused....exit\n", lcore_id);
			break;
	}

	return 0;
}


/* Check the link status of all ports in up to 9s, and print them finally */
void DpdkCpp::DpdkCpp::CheckAllPortsLinkStatus(unsigned int port_mask)
{
#define CHECK_INTERVAL 100 /* 100ms */
#define MAX_CHECK_TIME 90 /* 9s (90 * 100ms) in total */
	uint16_t portid;
	uint8_t count, all_ports_up, print_flag = 0;
	struct rte_eth_link link;

	printf("\nChecking link status");
	fflush(stdout);
	for (count = 0; count <= MAX_CHECK_TIME; count++) {
		if (force_quit)
			return;
		all_ports_up = 1;
		RTE_ETH_FOREACH_DEV(portid) {
			if (force_quit)
				return;
			if ((port_mask & (1 << portid)) == 0)
				continue;
			memset(&link, 0, sizeof(link));
			rte_eth_link_get_nowait(portid, &link);
			/* print link status if flag set */
			if (print_flag == 1) {
				if (link.link_status)
					printf(
					"Port%d Link Up. Speed %u Mbps - %s\n",
						portid, link.link_speed,
				(link.link_duplex == ETH_LINK_FULL_DUPLEX) ?
					("full-duplex") : ("half-duplex\n"));
				else
					printf("Port %d Link Down\n", portid);
				continue;
			}
			/* clear all_ports_up flag if any link down */
			if (link.link_status == ETH_LINK_DOWN) {
				all_ports_up = 0;
				break;
			}
		}
		/* after finally printing all link status, get out */
		if (print_flag == 1)
			break;

		if (all_ports_up == 0) {
			printf(".");
			fflush(stdout);
			rte_delay_ms(CHECK_INTERVAL);
		}

		/* set the print_flag if all ports up or timeout */
		if (all_ports_up == 1 || count == (MAX_CHECK_TIME - 1)) {
			print_flag = 1;
			printf("done\n");
		}
	}
}


void signal_handler(int signum)
{
	if (signum == SIGINT || signum == SIGTERM) {
		printf("\n\nSignal %d received, preparing to exit...\n",
				signum);
		force_quit = true;
	}
}


struct lcore_queue_conf *qconf;
int ret;
uint16_t nb_ports;
uint16_t nb_ports_available = 0;
uint16_t portid, last_port;
unsigned lcore_id, rx_lcore_id,write_lcore_id,stat_lcore_id;
unsigned nb_ports_in_mask = 0;
unsigned int nb_lcores = 0;
unsigned int nb_mbufs;

int DpdkCpp::InitEal()
{
	char **argvlist;
	unsigned int paramid= 0,argcsize= 10;
	l2fwd_enabled_port_mask= 0x01;	
	l2fwd_rx_queue_per_lcore= 0x02;
	l2fwd_enabled_core_mask= 0x07;

	argvlist= (char**)malloc(argcsize* sizeof(char*));
	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"TrafficMonitor");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"-c");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	sprintf(argvlist[paramid++],"%d",l2fwd_enabled_core_mask);


	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"-n");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	sprintf(argvlist[paramid++],"%d",4);

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"--");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"-p");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	sprintf(argvlist[paramid++],"%d",l2fwd_enabled_port_mask);

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"-q");

	/* init EAL */
	ret = rte_eal_init(argcsize, argvlist);

	return ret;
}

int DpdkCpp::InitPortQueue()
{
	char name[128];	
	nb_ports = rte_eth_dev_count_avail();
	if (nb_ports == 0)
		rte_exit(EXIT_FAILURE, "No Ethernet ports - bye\n");

	/* check port mask to possible port mask */
	if (l2fwd_enabled_port_mask & ~((1 << nb_ports) - 1))
		rte_exit(EXIT_FAILURE, "Invalid portmask; possible (0x%x)\n",
			(1 << nb_ports) - 1);


	for (portid = 0; portid < RTE_MAX_ETHPORTS; portid++)
		capture_port_conf[portid].dst_port= 0;
			
	last_port = 0;

	/*
	 * Each logical core is assigned a dedicated TX queue on each port.
	 */
	RTE_ETH_FOREACH_DEV(portid) {
		/* skip ports that are not enabled */
		if ((l2fwd_enabled_port_mask & (1 << portid)) == 0)
			continue;

		if (nb_ports_in_mask % 2) {
			capture_port_conf[portid].dst_port= last_port;
			capture_port_conf[last_port].dst_port= portid;
			
			snprintf(name, sizeof(name), "capture_port%u_tx_ring", portid);
			capture_port_conf[portid].tx_ring = rte_ring_create(name, CAPTURE_RING_SIZE, rte_socket_id(), RING_F_SP_ENQ | RING_F_SC_DEQ);
			snprintf(name, sizeof(name), "capture_port%u_worker_ring", portid);
			capture_port_conf[portid].worker_ring = rte_ring_create(name, CAPTURE_RING_SIZE, rte_socket_id(), RING_F_SP_ENQ | RING_F_SC_DEQ);
			snprintf(name, sizeof(name), "capture_port%u_tx_ring", last_port);
			capture_port_conf[last_port].tx_ring = rte_ring_create(name, CAPTURE_RING_SIZE, rte_socket_id(), RING_F_SP_ENQ | RING_F_SC_DEQ);
			snprintf(name, sizeof(name), "capture_port%u_worker_ring", last_port);
			capture_port_conf[last_port].worker_ring = rte_ring_create(name, CAPTURE_RING_SIZE, rte_socket_id(), RING_F_SP_ENQ | RING_F_SC_DEQ);

			if(capture_port_conf[portid].tx_ring == NULL)
				rte_exit(EXIT_FAILURE, "Cannot create tx ring for port%u\n", portid);
			else if(capture_port_conf[portid].worker_ring == NULL)
				rte_exit(EXIT_FAILURE, "Cannot create worker ring for port%u\n", portid);
			else if(capture_port_conf[last_port].tx_ring == NULL)
				rte_exit(EXIT_FAILURE, "Cannot create tx ring for port%u\n", last_port);
			else if(capture_port_conf[last_port].worker_ring == NULL)
				rte_exit(EXIT_FAILURE, "Cannot create worker ring for port%u\n", last_port);

		}
		else
			last_port = portid;

		nb_ports_in_mask++;
	}
	if (nb_ports_in_mask % 2) {
		printf("Notice: odd number of ports in portmask.\n");
		
		capture_port_conf[last_port].dst_port= last_port;
		
		snprintf(name, sizeof(name), "capture_port%u_tx_ring", last_port);
		capture_port_conf[last_port].tx_ring = rte_ring_create(name, CAPTURE_RING_SIZE, rte_socket_id(), RING_F_SP_ENQ | RING_F_SC_DEQ);
		snprintf(name, sizeof(name), "capture_port%u_worker_ring", last_port);
		capture_port_conf[last_port].worker_ring = rte_ring_create(name, CAPTURE_RING_SIZE, rte_socket_id(), RING_F_SP_ENQ | RING_F_SC_DEQ);

		if(capture_port_conf[last_port].tx_ring == NULL)
			rte_exit(EXIT_FAILURE, "Cannot create tx ring for port%u\n", last_port);
		else if(capture_port_conf[last_port].worker_ring == NULL)
			rte_exit(EXIT_FAILURE, "Cannot create worker ring for port%u\n", last_port);

		
	}


	/* Initialize the port/queue configuration of each logical core */
	RTE_ETH_FOREACH_DEV(portid) {
		/* skip ports that are not enabled */
		if ((l2fwd_enabled_port_mask & (1 << portid)) == 0)
			continue;

		/* get the lcore_id for this port */
		printf("\n****  rte_lcore_is_enabled(rx_lcore_id) =%d  lcore_queue_conf[rx_lcore_id].n_rx_port=%d l2fwd_rx_queue_per_lcore=%d\n",
rte_lcore_is_enabled(rx_lcore_id) ,
lcore_queue_conf[rx_lcore_id].n_rx_port,
l2fwd_rx_queue_per_lcore);
		while (rte_lcore_is_enabled(rx_lcore_id) == 0 ||
		       lcore_queue_conf[rx_lcore_id].n_rx_port ==
		       l2fwd_rx_queue_per_lcore) {
			rx_lcore_id++;
			printf("rx_lcore_id++ \n");
			if (rx_lcore_id >= RTE_MAX_LCORE)
				rte_exit(EXIT_FAILURE, "Not enough cores\n");
		}

		lcore_type_conf[rx_lcore_id] = rx;
		if (qconf != &lcore_queue_conf[rx_lcore_id]) {
			/* Assigned a new logical core in the loop above. */
			qconf = &lcore_queue_conf[rx_lcore_id];
			nb_lcores++;
		}

		qconf->rx_port_list[qconf->n_rx_port] = portid;
		qconf->n_rx_port++;
		printf("Lcore %u: RX port %u\n", rx_lcore_id, portid);
	}

	write_lcore_id=rx_lcore_id+1;
	while(rte_lcore_is_enabled(write_lcore_id) == 0 )
	{
		write_lcore_id++;
		if (write_lcore_id >= RTE_MAX_LCORE)
				rte_exit(EXIT_FAILURE, "Not enough cores\n");
	}

	RTE_ETH_FOREACH_DEV(portid) {
		/* skip ports that are not enabled */
		if ((l2fwd_enabled_port_mask & (1 << portid)) == 0)
			continue;

		/* get the lcore_id for this port */
		while (rte_lcore_is_enabled(write_lcore_id) == 0 ) {
			write_lcore_id++;
			if (write_lcore_id >= RTE_MAX_LCORE)
				rte_exit(EXIT_FAILURE, "Not enough cores\n");
		}

		lcore_type_conf[write_lcore_id] = write;
		if (qconf != &lcore_queue_conf[write_lcore_id]) {
			/* Assigned a new logical core in the loop above. */
			qconf = &lcore_queue_conf[write_lcore_id];
			nb_lcores++;
		}

		qconf->rx_port_list[qconf->n_rx_port] = portid;
		qconf->n_rx_port++;
		printf("Lcore %u: Write port %u\n", write_lcore_id, portid);
	}


	stat_lcore_id=write_lcore_id+1;
	while(rte_lcore_is_enabled(stat_lcore_id) == 0 )
	{
		stat_lcore_id++;
		if (stat_lcore_id >= RTE_MAX_LCORE)
				rte_exit(EXIT_FAILURE, "Not enough cores\n");
	}

	RTE_ETH_FOREACH_DEV(portid) {
		/* skip ports that are not enabled */
		if ((l2fwd_enabled_port_mask & (1 << portid)) == 0)
			continue;

		/* get the lcore_id for this port */
		while (rte_lcore_is_enabled(stat_lcore_id) == 0 ) {
			stat_lcore_id++;
			if (stat_lcore_id >= RTE_MAX_LCORE)
				rte_exit(EXIT_FAILURE, "Not enough cores\n");
		}

		lcore_type_conf[stat_lcore_id] = stat;
		if (qconf != &lcore_queue_conf[stat_lcore_id]) {
			/* Assigned a new logical core in the loop above. */
			qconf = &lcore_queue_conf[stat_lcore_id];
			nb_lcores++;
		}

		qconf->rx_port_list[qconf->n_rx_port] = portid;
		qconf->n_rx_port++;
		printf("Lcore %u: Stat port %u\n", stat_lcore_id, portid);
	}





}

int DpdkCpp::InitAllPort()
{
	qconf = NULL;


	nb_mbufs = RTE_MAX(nb_ports * (nb_rxd + nb_txd + MAX_PKT_BURST +
		nb_lcores * MEMPOOL_CACHE_SIZE), 8192U);

	/* create the mbuf pool */
	l2fwd_pktmbuf_pool = rte_pktmbuf_pool_create("mbuf_pool", nb_mbufs,
		MEMPOOL_CACHE_SIZE, 0, RTE_MBUF_DEFAULT_BUF_SIZE,
		rte_socket_id());
	if (l2fwd_pktmbuf_pool == NULL)
		rte_exit(EXIT_FAILURE, "Cannot init mbuf pool\n");
		memset(&port_conf,0,sizeof(port_conf));

		port_conf.rxmode.split_hdr_size = 0l;
		port_conf.rxmode.ignore_offload_bitfield = 1;
		port_conf.rxmode.offloads = DEV_RX_OFFLOAD_CRC_STRIP;
		port_conf.txmode.mq_mode = ETH_MQ_TX_NONE;

	/* Initialise each port */
	RTE_ETH_FOREACH_DEV(portid) {
		struct rte_eth_rxconf rxq_conf;
		struct rte_eth_txconf txq_conf;
		struct rte_eth_conf local_port_conf = port_conf;
		struct rte_eth_dev_info dev_info;

		/* skip ports that are not enabled */
		if ((l2fwd_enabled_port_mask & (1 << portid)) == 0) {
			printf("Skipping disabled port %u\n", portid);
			continue;
		}
		nb_ports_available++;

		/* init port */
		printf("Initializing port %u... ", portid);
		fflush(stdout);
		rte_eth_dev_info_get(portid, &dev_info);
		if (dev_info.tx_offload_capa & DEV_TX_OFFLOAD_MBUF_FAST_FREE)
			local_port_conf.txmode.offloads |=
				DEV_TX_OFFLOAD_MBUF_FAST_FREE;
		ret = rte_eth_dev_configure(portid, 1, 1, &local_port_conf);
		if (ret < 0)
			rte_exit(EXIT_FAILURE, "Cannot configure device: err=%d, port=%u\n",
				  ret, portid);

		ret = rte_eth_dev_adjust_nb_rx_tx_desc(portid, &nb_rxd,
						       &nb_txd);
		if (ret < 0)
			rte_exit(EXIT_FAILURE,
				 "Cannot adjust number of descriptors: err=%d, port=%u\n",
				 ret, portid);

		rte_eth_macaddr_get(portid,&capture_port_conf [portid].eth_addr);

		/* init one RX queue */
		fflush(stdout);
		rxq_conf = dev_info.default_rxconf;
		rxq_conf.offloads = local_port_conf.rxmode.offloads;
		ret = rte_eth_rx_queue_setup(portid, 0, nb_rxd,
					     rte_eth_dev_socket_id(portid),
					     &rxq_conf,
					     l2fwd_pktmbuf_pool);
		if (ret < 0)
			rte_exit(EXIT_FAILURE, "rte_eth_rx_queue_setup:err=%d, port=%u\n",
				  ret, portid);

		/* init one TX queue on each port */
		fflush(stdout);
		txq_conf = dev_info.default_txconf;
		txq_conf.txq_flags = ETH_TXQ_FLAGS_IGNORE;
		txq_conf.offloads = local_port_conf.txmode.offloads;
		ret = rte_eth_tx_queue_setup(portid, 0, nb_txd,
				rte_eth_dev_socket_id(portid),
				&txq_conf);
		if (ret < 0)
			rte_exit(EXIT_FAILURE, "rte_eth_tx_queue_setup:err=%d, port=%u\n",
				ret, portid);

		/* Initialize TX buffers */
		tx_buffer[portid] =(rte_eth_dev_tx_buffer*) rte_zmalloc_socket("tx_buffer",
				RTE_ETH_TX_BUFFER_SIZE(MAX_PKT_BURST), 0,
				rte_eth_dev_socket_id(portid));
		if (tx_buffer[portid] == NULL)
			rte_exit(EXIT_FAILURE, "Cannot allocate buffer for tx on port %u\n",
					portid);

		rte_eth_tx_buffer_init(tx_buffer[portid], MAX_PKT_BURST);

		ret = rte_eth_tx_buffer_set_err_callback(tx_buffer[portid],
				rte_eth_tx_buffer_count_callback,
				&port_statistics[portid].dropped);
		if (ret < 0)
			rte_exit(EXIT_FAILURE,
			"Cannot set error callback for tx buffer on port %u\n",
				 portid);

		/* Start device */
		ret = rte_eth_dev_start(portid);
		if (ret < 0)
			rte_exit(EXIT_FAILURE, "rte_eth_dev_start:err=%d, port=%u\n",
				  ret, portid);

		printf("done: \n");

		rte_eth_promiscuous_enable(portid);

		printf("Port %u, MAC address: %02X:%02X:%02X:%02X:%02X:%02X\n\n",
				portid,
				capture_port_conf [portid].eth_addr.addr_bytes[0],
				capture_port_conf [portid].eth_addr.addr_bytes[1],
				capture_port_conf [portid].eth_addr.addr_bytes[2],
				capture_port_conf [portid].eth_addr.addr_bytes[3],
				capture_port_conf [portid].eth_addr.addr_bytes[4],
				capture_port_conf [portid].eth_addr.addr_bytes[5]);

		/* initialize port stats */
		memset(&port_statistics, 0, sizeof(port_statistics));
	}

}

void DpdkCpp::DpdkCpp::LaunchAllLcore()
{
	ret = 0;
	/* launch per-lcore init on every lcore */
	rte_eal_mp_remote_launch(l2fwd_launch_one_lcore, NULL, CALL_MASTER);
	RTE_LCORE_FOREACH_SLAVE(lcore_id) {
		if (rte_eal_wait_lcore(lcore_id) < 0) {
			ret = -1;
			break;
		}
	}
	
}
void DpdkCpp::CloseAllPort()
{
		RTE_ETH_FOREACH_DEV(portid) {
		if ((l2fwd_enabled_port_mask & (1 << portid)) == 0)
			continue;
		printf("Closing port %d...", portid);
		rte_eth_dev_stop(portid);
		rte_eth_dev_close(portid);
		printf(" Done\n");
	}
	printf("Bye...\n");
}
	
int DpdkCpp::InitDpdk(DpdkUserBinThread* rxthread,DpdkUserBinThread* statthread,DpdkUserBinThread* writethread)
{
	gwritethread= writethread;

	ret=InitEal();
	if (ret < 0)
		rte_exit(EXIT_FAILURE, "Invalid EAL arguments\n");

	force_quit = false;
	signal(SIGINT, signal_handler);
	signal(SIGTERM, signal_handler);

	//* convert to number of cycles 
	timer_period *= rte_get_timer_hz();

	rx_lcore_id = 0;
	InitPortQueue();
	InitAllPort();
	if (!nb_ports_available) {
		rte_exit(EXIT_FAILURE,
			"All available ports are disabled. Please set portmask.\n");
	}
	CheckAllPortsLinkStatus(l2fwd_enabled_port_mask);
	
	LaunchAllLcore();

	CloseAllPort();
	return ret;
}


};


