#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/queue.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <setjmp.h>
#include <stdarg.h>
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <signal.h>
#include <stdbool.h>
#include <unistd.h>

#include <rte_common.h>
#include <rte_log.h>
#include <rte_memory.h>
#include <rte_memcpy.h>
#include <rte_memzone.h>
#include <rte_eal.h>
#include <rte_per_lcore.h>
#include <rte_launch.h>
#include <rte_atomic.h>
#include <rte_cycles.h>
#include <rte_prefetch.h>
#include <rte_lcore.h>
#include <rte_per_lcore.h>
#include <rte_branch_prediction.h>
#include <rte_interrupts.h>
#include <rte_pci.h>
#include <rte_random.h>
#include <rte_debug.h>
#include <rte_ether.h>
#include <rte_arp.h>
#include <rte_ip.h>
#include <rte_tcp.h>
#include <rte_udp.h>
#include <rte_icmp.h>
#include <rte_ethdev.h>
#include <rte_ring.h>
#include <rte_mempool.h>
#include <rte_mbuf.h>

#include "pcapng.h"

#include "PacketWriteThread.h"


namespace pcpp
{

uint32_t PcapWriteFile::m_maxWriteCount= 10000;//1����
uint32_t PcapWriteFile::m_maxWriteTimeMin= 10;//10����
PcapWriteFile::PcapWriteFile(char* filename):m_writeCount(0),m_bClose(true)
{	
	memset(m_fileName,0,128);
	sprintf(m_fileName,"%s.pcapng",filename);
	m_fp = fopen(m_fileName, "wb");
	if (NULL== m_fp)
	{
		printf("Cannot open %s file.\n",m_fileName);
		return;
	}
	else
		WritePcapngHeader();

		printf("Open %s file OK.\n",m_fileName);
	m_bClose= false;
	m_beginWriteMin= GetCurTimeMinCount();
}

uint32_t PcapWriteFile::GetCurTimeMinCount()
{
	//��ȡ��ǰʱ��  
	time_t now_time=time(NULL);  
	tm*  t_tm = localtime(&now_time);  
	
	return t_tm->tm_hour*60+t_tm->tm_min;
}

void PcapWriteFile::WritePcapngHeader()
{
	struct block_header bh;
	struct section_header_block shb;
	struct block_trailer bt;
	struct interface_description_block idb;
	struct option_header oh;
	uint32_t msb = 6;

	bh.block_type = BT_SHB;
	bh.total_length = 28;
	fwrite(&bh, 1, sizeof(struct block_header), m_fp);
	shb.byte_order_magic = BYTE_ORDER_MAGIC;
	shb.major_version = PCAP_NG_VERSION_MAJOR;
	shb.minor_version = PCAP_NG_VERSION_MINOR;
	shb.section_length = 0xFFFFFFFFFFFFFFFF;
	fwrite(&shb, 1, sizeof(struct section_header_block), m_fp);
	bt.total_length = 28;
	fwrite(&bt, 1, sizeof(struct block_trailer), m_fp);

	bh.block_type = BT_IDB;
	bh.total_length = 32;
	fwrite(&bh, 1, sizeof(struct block_header), m_fp);
	idb.linktype = 1;
	idb.reserved = 0;
	idb.snaplen = 0xFFFF;
	
	fwrite(&idb, 1, sizeof(struct interface_description_block), m_fp);
	oh.option_code = 9;
	oh.option_length = 1;
	fwrite(&oh, 1, sizeof(struct option_header), m_fp);
	fwrite(&msb, 1, sizeof(uint32_t), m_fp);
	oh.option_code = OPT_ENDOFOPT;
	oh.option_length = 0;
	fwrite(&oh, 1, sizeof(struct option_header), m_fp);
	bt.total_length = 32;
	fwrite(&bt, 1, sizeof(struct block_trailer), m_fp);
}

bool PcapWriteFile::TryWritePacket(uint8_t *packet, uint64_t pkt_len, uint64_t arrival_time)
{
	if(unlikely(m_bClose))
		return false;

	uint32_t curmincount,difmin;
	if(unlikely(m_writeCount> m_maxWriteCount))
		return false;

	curmincount= GetCurTimeMinCount();
	difmin= (curmincount- m_beginWriteMin+1440)%1440;
	if(unlikely(m_maxWriteTimeMin< difmin))
		return false;
		
	WritePacket(packet, pkt_len, arrival_time);

	return true;
}	

void PcapWriteFile::WritePacket(uint8_t *packet, uint64_t pkt_len, uint64_t arrival_time)
{
	struct block_header bh;
	struct enhanced_packet_block epb;
	struct block_trailer bt;

	int ret;
	uint32_t offset,padding,fakepadding;

	if(unlikely(m_bClose))
		return ;

	ret = 0;
	offset = 0;
	padding = 0;
	fakepadding = 0;

	offset = pkt_len;
	padding = offset % 4 ? (4 - offset % 4) : 0;
	bh.block_type = BT_EPB;
	bh.total_length = 32 + offset + padding;
	bt.total_length = 32 + offset + padding;
	epb.interface_id = 0;
	epb.timestamp_high = (uint32_t)(arrival_time >> 32);
	epb.timestamp_low = (uint32_t)arrival_time;
	epb.caplen = offset;
	epb.len = offset;
	fwrite(&bh, 1, sizeof(struct block_header), m_fp);
	fwrite(&epb, 1, sizeof(struct enhanced_packet_block), m_fp);
	ret = fwrite(packet, 1, pkt_len, m_fp);
	ret += fwrite(&fakepadding, 1, padding, m_fp);
	fwrite(&bt, 1, sizeof(struct block_trailer), m_fp);
	
	++m_writeCount;
}



bool PacketWriteThread::CreateNewPcapFile(uint64_t hashid)
{
	PcapWriteFile* pcapfile= NULL;
	char filename[64];
	std::map<uint64_t,PcapWriteFile*>::iterator fp;
		fp= m_writeFPList.find(hashid);

	if(fp!= m_writeFPList.end())
		return false;

	sprintf(filename,"%d",hashid);
	pcapfile= new PcapWriteFile(filename);
	m_writeFPList.insert(std::make_pair(hashid,pcapfile));
}

PacketWriteThread::PacketWriteThread()
{
	
}

PacketWriteThread::~PacketWriteThread()
{
	std::map<uint64_t,PcapWriteFile*>::iterator fp;
	for(fp= m_writeFPList.begin();fp!= m_writeFPList.end();++fp)
	{
		if(fp->second)
			delete fp->second;
	}
	m_writeFPList.clear();
}

bool PacketWriteThread::Run(uint64_t hasharr[],uint8_t *packet[],uint32_t len)
{
	printf("WritePacketThread \n");
	
	std::map<uint64_t,PcapWriteFile*>::iterator fp;
	for(uint32_t i= 0;i< len;++i)
	{
		fp= m_writeFPList.find(hasharr[i]);
		if(fp!= m_writeFPList.end())
		{
			if(0)//fp->TryWritePacket())
			{
				m_writeFPList.erase(fp);
			}
		}

	}


	return m_bStop;
}


};
