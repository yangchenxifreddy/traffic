#pragma once
#include "DpdkCpp.h"
#include <stdint.h>
#include <inttypes.h>
#include <map>

namespace pcpp
{

class PcapWriteFile
{
private:
	FILE *m_fp;
	uint32_t m_writeCount;
	uint32_t m_beginWriteMin;
	bool m_bClose;
	static uint32_t m_maxWriteCount;	
	static uint32_t m_maxWriteTimeMin;
	char	m_fileName[128];
private:
	uint32_t GetCurTimeMinCount();
	void WritePcapngHeader();
public:
	PcapWriteFile(char* filename);
	virtual ~PcapWriteFile()
	{

		if(NULL!= m_fp)
		{
			fclose(m_fp);
			delete m_fp;
		}
	}

	bool TryWritePacket(uint8_t *packet, uint64_t pkt_len, uint64_t arrival_time);
	void WritePacket(uint8_t *packet, uint64_t pkt_len, uint64_t arrival_time);
	void OpenFile()
	{
		m_fp = fopen(m_fileName, "wb");
		if (NULL== m_fp)
		{
			printf("Cannot open %s.pcapng file.\n",m_fileName);
			return;
		}
		m_bClose= false;
		m_beginWriteMin= GetCurTimeMinCount();
	}

	void CloseFile()
	{
		m_writeCount= 0;
		m_bClose= true;
		if(NULL!= m_fp)
			fclose(m_fp);
	}

};


class PacketWriteThread:public DpdkUserBinThread
{
private:
	std::map<uint64_t,PcapWriteFile*> m_writeFPList;
public:
	PacketWriteThread();
	virtual ~PacketWriteThread();
	bool CreateNewPcapFile(uint64_t);
	virtual bool Run(uint64_t hasharr[],uint8_t *packet[],uint32_t len);
	virtual void Stop(){};
	
};

};
